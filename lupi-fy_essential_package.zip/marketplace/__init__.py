# Marketplace app initialization
