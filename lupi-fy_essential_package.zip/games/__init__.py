"""games app - minimal stub to satisfy tests and provide recently-played API"""

default_app_config = "games.apps.GamesConfig"
